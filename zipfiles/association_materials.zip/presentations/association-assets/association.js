(() => {
  const byId = id => document.getElementById(id);
  const set = (id, value) => { byId(id).textContent = value; };
  const mean = values => values.reduce((sum, value) => sum + value, 0) / values.length;
  const number = (x, digits = 2) => Number.isNaN(x) ? 'Undefined'
    : x === Infinity ? '∞'
    : (Math.abs(x) < 0.5 * 10 ** -digits ? 0 : x).toFixed(digits);
  const palette = ['#287ab8', '#bb4c34', '#18304a'];
  const ink = '#18304a';
  const muted = '#617080';

  function pearson(x, y) {
    const xMean = mean(x);
    const yMean = mean(y);
    let cross = 0, xSquares = 0, ySquares = 0;
    x.forEach((value, i) => {
      const dx = value - xMean;
      const dy = y[i] - yMean;
      cross += dx * dy;
      xSquares += dx * dx;
      ySquares += dy * dy;
    });
    return cross / Math.sqrt(xSquares * ySquares);
  }

  function ranks(values) {
    const order = values.map((_, index) => index).sort((a, b) => values[a] - values[b]);
    const assigned = [];
    let start = 0;
    while (start < order.length) {
      let end = start + 1;
      while (end < order.length && values[order[start]] === values[order[end]]) end++;
      for (let i = start; i < end; i++) assigned[order[i]] = (start + end + 1) / 2;
      start = end;
    }
    return assigned;
  }

  function kendall(x, y) {
    let balance = 0, untiedX = 0, untiedY = 0;
    for (let i = 0; i < x.length; i++) {
      for (let j = i + 1; j < x.length; j++) {
        const dx = Math.sign(x[i] - x[j]);
        const dy = Math.sign(y[i] - y[j]);
        untiedX += Math.abs(dx);
        untiedY += Math.abs(dy);
        balance += dx * dy;
      }
    }
    return balance / Math.sqrt(untiedX * untiedY);
  }

  function correlations(points) {
    const x = points.map(point => point[0]);
    const y = points.map(point => point[1]);
    return [pearson(x, y), pearson(ranks(x), ranks(y)), kendall(x, y)];
  }

  function setupWalkthrough(demo, cells, transpose, readCounts) {
    const select = byId('walk-measure');
    const panel = byId('walk-panel');
    const rows = byId('walk-rows');
    const back = byId('walk-back'), next = byId('walk-next'), showAll = byId('walk-show-all');
    let step = -1;

    function draw(animate = true) {
      const counts = readCounts();
      const valid = counts.every(Number.isFinite);
      const active = step >= 0 && valid;
      const odds = select.value === 'OR';
      const groups = transpose.checked ? ['Died', 'Recovered'] : ['Placebo', 'Treatment'];
      const event = transpose.checked ? 'received placebo' : 'died';
      const other = transpose.checked ? 'received treatment' : 'recovered';
      const cell = index => ({text: String(counts[index]), source: index});
      const derived = text => ({text});
      const fraction = offset => ({
        numerator: [cell(offset)],
        denominator: odds ? [cell(offset + 1)] : [cell(offset), ' + ', cell(offset + 1)]
      });
      panel.hidden = !active;
      demo.classList.toggle('walking', active);
      back.disabled = !active;
      next.disabled = !valid;
      showAll.disabled = !valid || step === 2;
      next.textContent = step < 0 ? 'Show first step' : step === 2 ? 'Finish' : 'Next step';
      const cellColors = transpose.checked ? [0, 2, 1, 3] : [0, 1, 2, 3];
      cells.forEach((input, i) => {
        input.dataset.cell = cellColors[i];
        input.classList.remove('walk-source');
      });
      rows.replaceChildren();
      if (!active) return;

      const [a,b,c,d] = counts;
      const p = a / (a+b), q = c / (c+d);
      const moving = [];
      const indexed = i => ({text: odds ? 'Odds' : 'Risk', group: groups[i]});
      const rd = select.value === 'RD';
      for (let i = 0; i <= step; i++) {
        const row = document.createElement('div');
        row.className = 'walk-equation';
        rows.append(row);
        let terms;
        if (i < 2) {
          const offset = 2 * i;
          const value = odds ? number(counts[offset] / counts[offset + 1]) : number(i === 0 ? p : q, 3);
          terms = [indexed(i), ' = ', fraction(offset), ' = ', derived(value)];
        } else {
          const result = rd ? number(p - q, 3) : number(odds ? (a*d)/(b*c) : p/q);
          const comparison = rd ? [indexed(0), ' − ', indexed(1)]
            : [{numerator: [indexed(0)], denominator: [indexed(1)]}];
          terms = [select.value + ' = ', ...comparison, ' = ', derived(result)];
        }
        function renderTerm(term) {
          if (term.numerator) {
            const frac = document.createElement('span');
            frac.className = 'assoc-fraction';
            for (const parts of [term.numerator, term.denominator]) {
              const line = document.createElement('span');
              parts.forEach(part => line.append(renderTerm(part)));
              frac.append(line);
            }
            return frac;
          }
          const token = document.createElement('span');
          token.textContent = typeof term === 'string' ? term : term.text;
          if (term.group !== undefined) {
            const sub = document.createElement('sub');
            sub.textContent = term.group;
            token.append(sub);
          }
          if (term.source !== undefined) {
            const input = cells[term.source];
            token.className = 'walk-value';
            token.dataset.cell = input.dataset.cell;
            if (i === step) {
              input.classList.add('walk-source');
              moving.push([token, input]);
            }
          }
          return token;
        }
        terms.forEach(term => row.append(renderTerm(term)));
      }
      set('walk-why', step < 2
        ? 'Divide the number who ' + event + ' by ' + (odds ? 'the number who ' + other : 'the total number of participants') + ' in the same row.'
        : rd ? 'Subtract the reference risk to get the absolute difference in risk.'
          : 'Divide by the reference ' + (odds ? 'odds' : 'risk') + ' to express the comparison as a multiple.');
      if (!animate || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      moving.forEach(([token, input], i) => {
        const to = token.getBoundingClientRect(), from = input.getBoundingClientRect();
        if (!to.width || !token.animate) return;
        const scale = token.offsetWidth / to.width;
        const dx = (from.left + from.width/2 - to.left - to.width/2) * scale;
        const dy = (from.top + from.height/2 - to.top - to.height/2) * scale;
        token.animate([{transform: 'translate(' + dx + 'px,' + dy + 'px)', opacity: .5},
          {transform: 'translate(0,0)', opacity: 1}], {duration: 550, delay: i*85, fill: 'backwards', easing: 'ease-out'});
      });
    }

    next.addEventListener('click', () => { step = step === 2 ? -1 : step + 1; draw(); });
    back.addEventListener('click', () => { step--; draw(false); });
    showAll.addEventListener('click', () => { step = 2; draw(false); });
    select.addEventListener('change', () => { step = 0; draw(); });
    return {refresh() { if (!readCounts().every(Number.isFinite)) step = -1; draw(false); }};
  }

  function setupBinary() {
    const demo = byId('binary-demo');
    const cells = [...demo.querySelectorAll('input[type="number"]')];
    const presets = [...demo.querySelectorAll('[data-counts]')];
    const transpose = byId('transpose-table');
    const labels = [...demo.querySelectorAll('.assoc-bar-label')];
    const bars = [...demo.querySelectorAll('.assoc-bar span')];
    const writeCounts = counts => cells.forEach((input, i) => { input.value = counts[i]; });
    const transposeCounts = ([a, b, c, d]) => [a, c, b, d];
    const readCounts = () => cells.map(input => input.validity.valid ? input.valueAsNumber : NaN);

    const guide = setupWalkthrough(demo, cells, transpose, readCounts);

    function update() {
      const counts = readCounts();
      const valid = counts.every(Number.isFinite);
      const [a, b, c, d] = counts;
      const swapped = transpose.checked;
      const rowNames = swapped ? ['Died', 'Recovered'] : ['Placebo', 'Treatment'];
      const risks = valid ? [a / (a + b), c / (c + d)] : [NaN, NaN];
      set('row-variable', swapped ? 'Outcome' : 'Group');
      set('first-row', rowNames[0]);
      set('second-row', rowNames[1]);
      set('first-column', swapped ? 'Placebo' : 'Died');
      set('second-column', swapped ? 'Treatment' : 'Recovered');
      set('binary-question', swapped ? 'Event: received placebo' : 'Event: death');
      risks.forEach((risk, i) => {
        const percent = 100 * risk;
        set('summary-group-' + i, rowNames[i]);
        set('summary-odds-' + i, number(valid ? counts[2*i] / counts[2*i + 1] : NaN));
        labels[i].textContent = number(risk, 3);
        bars[i].style.width = Number.isFinite(percent) ? percent + '%' : '0%';
      });
      guide.refresh();
      const colored = counts.map((count, i) =>
        '<span class="walk-value" data-cell="' + cells[i].dataset.cell + '">' + count + '</span>');
      const [first, second, third, fourth] = colored;
      const frac = (top, bottom) => '<span class="assoc-fraction"><span>' + top +
        '</span><span>' + bottom + '</span></span>';
      const risk1 = frac(first, first + ' + ' + second);
      const risk2 = frac(third, third + ' + ' + fourth);
      byId('rd-work').innerHTML = valid ? risk1 + ' − ' + risk2 : '';
      byId('rr-work').innerHTML = valid ? frac(first + ' / (' + first + ' + ' + second + ')',
        third + ' / (' + third + ' + ' + fourth + ')') : '';
      byId('or-work').innerHTML = valid ? frac(first + ' / ' + second, third + ' / ' + fourth) : '';
      const difference = risks[0] - risks[1];
      set('metric-rd', number(difference, 3));
      set('metric-rr', number(risks[0] / risks[1]));
      set('metric-or', number((a * d) / (b * c)));
      set('binary-note', !valid
        ? 'Enter a whole count from 0 to 1,000,000 in each cell.'
        : swapped
          ? 'The question now conditions on outcome. Compare the new RD and RR with the original OR.'
          : 'Compare Rare event with Common event. OR is close to RR when the event is rare in both groups. How does RD change?');
      const initialOrder = swapped ? transposeCounts(counts) : counts;
      presets.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.counts === initialOrder.join(','))));
    }
    presets.forEach(button => button.addEventListener('click', () => {
      const counts = button.dataset.counts.split(',').map(Number);
      writeCounts(transpose.checked ? transposeCounts(counts) : counts);
      update();
    }));
    transpose.addEventListener('change', () => {
      writeCounts(transposeCounts(cells.map(input => input.value)));
      update();
    });
    cells.forEach(input => input.addEventListener('input', update));
    update();
  }

  const plotSizes = new WeakMap();

  function plot(canvas, {xlim, ylim, xLabel, yLabel, xTicks, yTicks, rowLabels = []}) {
    // Reveal scales the slides for projection. Keep extra pixels in the canvas
    // while drawing with the original coordinate system and text sizes.
    if (!plotSizes.has(canvas)) plotSizes.set(canvas, {width: canvas.width, height: canvas.height});
    const {width, height} = plotSizes.get(canvas);
    const pixelScale = Math.max(3, Math.ceil(window.devicePixelRatio || 1));
    if (canvas.width !== width * pixelScale || canvas.height !== height * pixelScale) {
      canvas.width = width * pixelScale;
      canvas.height = height * pixelScale;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(pixelScale, 0, 0, pixelScale, 0, 0);
    const fontFamily = getComputedStyle(canvas.closest('.reveal')).fontFamily;
    const left = 78, right = width - 24, top = 23, bottom = height - 66;
    const x = value => left + (value - xlim[0]) / (xlim[1] - xlim[0]) * (right - left);
    const y = value => bottom - (value - ylim[0]) / (ylim[1] - ylim[0]) * (bottom - top);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#f6f9fc';
    ctx.fillRect(left, top, right - left, bottom - top);

    function line(x1, y1, x2, y2, colour) {
      ctx.strokeStyle = colour;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    ctx.fillStyle = muted;
    ctx.font = '18px ' + fontFamily;
    ctx.textAlign = 'center';
    xTicks.forEach(value => {
      line(x(value), top, x(value), bottom, '#d8e8f4');
      ctx.fillText(value, x(value), bottom + 25);
    });
    ctx.textAlign = 'right';
    yTicks.forEach(value => {
      line(left, y(value), right, y(value), '#d8e8f4');
      ctx.fillText(value, left - 10, y(value) + 6);
    });
    rowLabels.forEach(([value, text]) => ctx.fillText(text, left - 10, y(value) + 6));
    line(left, bottom, right, bottom, '#8292a1');
    line(left, top, left, bottom, '#8292a1');
    ctx.fillStyle = ink;
    ctx.font = 'bold 19px ' + fontFamily;
    ctx.textAlign = 'center';
    ctx.fillText(xLabel, (left + right) / 2, height - 13);
    if (yLabel) {
      ctx.save();
      ctx.translate(22, (top + bottom) / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(yLabel, 0, 0);
      ctx.restore();
    }

    function point(xValue, yValue, {colour = palette[0], radius = 6, alpha = 0.75, diamond = false, label = ''} = {}) {
      const px = x(xValue);
      const py = y(yValue);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = colour;
      ctx.beginPath();
      if (diamond) {
        ctx.moveTo(px, py - radius);
        ctx.lineTo(px + radius, py);
        ctx.lineTo(px, py + radius);
        ctx.lineTo(px - radius, py);
        ctx.closePath();
      } else {
        ctx.arc(px, py, radius, 0, 2 * Math.PI);
      }
      ctx.fill();
      ctx.globalAlpha = 1;
      if (label) {
        ctx.font = 'bold 16px ' + fontFamily;
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.fillText(label, px, py + 6);
      }
    }
    return point;
  }

  function setupMeans() {
    const canvas = byId('means-demo').querySelector('canvas');
    const shift = byId('mean-shift');
    const groupA = [-2.1, -1.5, -0.9, -0.7, -0.3, -0.2, 0, 0.2, 0.3, 0.7, 0.9, 1.5, 2.1];
    const groupB = [-1.7, -1.3, -1.1, -0.6, -0.4, -0.1, 0, 0.1, 0.4, 0.6, 1.1, 1.3, 1.7];

    function update() {
      const a = groupA.map(value => 5 + value + Number(shift.value));
      const b = groupB.map(value => 5 + value);
      const meanA = mean(a);
      const meanB = mean(b);
      const point = plot(canvas, {
        xlim: [-1, 12], ylim: [0, 3], xLabel: 'Laugh score', xTicks: [0, 2, 4, 6, 8, 10, 12],
        yTicks: [], rowLabels: [[2, 'A'], [1, 'B']]
      });
      [a, b].forEach((group, index) => {
        const centre = 2 - index;
        group.forEach((value, i) => point(value, centre + ((i * 7) % 5 - 2) * .12,
          {colour: palette[index], radius: 7, alpha: 0.52}));
        point(mean(group), centre, {colour: palette[index], radius: 13, alpha: 1, diamond: true});
      });
      shift.setAttribute('aria-valuetext', shift.value + ' laugh-score points');
      set('mean-a', number(meanA, 1));
      set('mean-b', number(meanB, 1));
      set('mean-difference', number(meanA - meanB, 1));
    }
    shift.addEventListener('input', update);
    byId('reset-means').addEventListener('click', () => { shift.value = 3; update(); });
    update();
  }

  function setupPatterns() {
    const canvas = byId('correlation-demo').querySelector('canvas');
    const shape = byId('scatter-shape');
    const outlier = byId('add-outlier');
    const xValues = Array.from({length: 21}, (_, i) => (i - 10) / 2);
    const patterns = {
      linear: x => .76 * x + Math.sin(x * 2.4) * .65,
      curved: x => 4.5 * (x / 5) ** 5,
      uShape: x => .30 * x ** 2 - 3
    };
    const explanations = {
      linear: 'A rising cloud gives positive coefficients. Try adding one distant point.',
      curved: 'The curve rises throughout. The order is preserved even though the slope changes.',
      uShape: 'The curve falls and then rises. All three coefficients are zero for these symmetric points.'
    };

    function update() {
      const points = xValues.map(x => [x, patterns[shape.value](x)]);
      if (outlier.checked) points.push([8, -7]);
      const point = plot(canvas, {
        xlim: [-6, 9], ylim: [-8, 6], xLabel: 'X', yLabel: 'Y',
        xTicks: [-5, 0, 5, 8], yTicks: [-6, -3, 0, 3, 6]
      });
      points.forEach(([x, y], i) => {
        const added = i === xValues.length;
        point(x, y, added ? {colour: palette[1], radius: 10, alpha: 1, diamond: true} : {});
      });
      correlations(points).forEach((value, i) => set(['pearson', 'spearman', 'kendall'][i], number(value)));
      set('pattern-caption', outlier.checked
        ? 'The red diamond is the added point. Compare how far each coefficient moves.'
        : explanations[shape.value]);
    }
    shape.addEventListener('change', update);
    outlier.addEventListener('change', update);
    update();
  }

  function setupCorrelationSteps() {
    const method = byId('correlation-method');
    const back = byId('correlation-back');
    const next = byId('correlation-next');
    const all = byId('correlation-all');
    const hours = [1, 2, 3];
    const scores = [10, 40, 20];
    const students = ['A', 'B', 'C'];
    const centered = values => values.map(value => value - mean(values));
    const deviationsX = centered(hours);
    const deviationsY = centered(scores);
    const products = deviationsX.map((value, i) => value * deviationsY[i]);
    let step = 0;

    const columns = ['Student', 'Hours', 'Score'];
    const deviationColumns = [
      ['xᵢ − x̄', deviationsX.map(value => number(value))],
      ['yᵢ − ȳ', deviationsY.map(value => number(value))]
    ];
    const rankColumns = [['Rank x', ranks(hours)], ['Rank y', ranks(scores)]];
    const baseRows = students.map((student, i) => [student, hours[i], scores[i]]);
    const pairs = [[0, 1], [0, 2], [1, 2]];

    const deviation = (axis, average) => `<mrow><mo>(</mo><msub><mi>${axis}</mi><mi>i</mi></msub>
      <mo>−</mo><mi class="mean-symbol">${average}</mi><mo>)</mo></mrow>`;
    const xDeviation = deviation('x', 'x̄');
    const yDeviation = deviation('y', 'ȳ');
    const steps = {
      pearson: [
        ['Centre each column', 'Subtract the column mean from each value.\nMean hours = 2. Mean score ≈ 23.33.'],
        ['Multiply within each row', 'Multiply the two deviations for each student.\nThe products sum to 10.'],
        ['Divide by the spread', 'The two sums of squared deviations are 2 and approximately 466.67.',
          `<math display="block" class="pearson-formula">
            <mi>r</mi><mo>=</mo>
            <mfrac>
              <mrow><mo>∑</mo>${xDeviation}${yDeviation}</mrow>
              <mrow>
                <msqrt><mrow><mo>∑</mo><msup>${xDeviation}<mn>2</mn></msup></mrow></msqrt>
                <mo>·</mo>
                <msqrt><mrow><mo>∑</mo><msup>${yDeviation}<mn>2</mn></msup></mrow></msqrt>
              </mrow>
            </mfrac>
          </math>
          <math display="block">
            <mi>r</mi><mo>≈</mo>
            <mfrac><mn>10</mn><msqrt><mrow><mn>2</mn><mo>×</mo><mn>466.67</mn></mrow></msqrt></mfrac>
            <mo>≈</mo><mn>${number(pearson(hours, scores))}</mn>
          </math>`]
      ],
      spearman: [
        ['Replace values with ranks', 'Rank each column from smallest to largest.\nTied values receive the average rank.'],
        ['Apply Pearson to the ranks', 'Both mean ranks are 2. The centred products sum to 1.\nEach sum of squared deviations is 2.',
          `<math display="block">
            <mi>ρ</mi><mo>=</mo>
            <mfrac><mn>1</mn><msqrt><mrow><mn>2</mn><mo>×</mo><mn>2</mn></mrow></msqrt></mfrac>
            <mo>=</mo><mn>${number(pearson(ranks(hours), ranks(scores)))}</mn>
          </math>`]
      ],
      kendall: [
        ...pairs.map(([i, j]) => {
          const agrees = scores[j] > scores[i];
          return [students[i] + ' and ' + students[j],
            students[j] + ' studied longer and scored ' + (agrees ? 'higher.\nSame order (+1).' : 'lower.\nOpposite order (−1).')];
        }),
        ['Combine the pair scores', 'Two pairs agree and one disagrees.\nWith no ties, divide by all three pairs.',
          `<math display="block">
            <msub><mi>τ</mi><mi>b</mi></msub><mo>=</mo>
            <mfrac><mrow><mn>2</mn><mo>−</mo><mn>1</mn></mrow><mn>3</mn></mfrac>
            <mo>≈</mo><mn>${number(kendall(hours, scores))}</mn>
          </math>`]
      ]
    };

    function cell(tag, value) {
      const element = document.createElement(tag);
      element.textContent = value;
      return element;
    }

    function draw(animate = true) {
      const selected = method.value;
      const visibleSteps = steps[selected].slice(0, step);
      const extra = selected === 'pearson' && step > 0
        ? [...deviationColumns, ...(step > 1 ? [['Product', products.map(value => number(value))]] : [])]
        : selected === 'spearman' && step > 0 ? rankColumns : [];
      const activePair = selected === 'kendall' ? pairs[step - 1] : undefined;
      function reservedCell(tag) {
        const element = cell(tag, ' ');
        element.className = 'correlation-reserved';
        return element;
      }
      const spareColumns = 3 - extra.length;
      const placeholders = tag => Array.from({length: spareColumns}, () => reservedCell(tag));
      byId('correlation-columns').replaceChildren(
        ...[...columns, ...extra.map(([label]) => label)].map(label => cell('th', label)),
        ...placeholders('th'));
      byId('correlation-observations').replaceChildren(...baseRows.map((values, i) => {
        const row = document.createElement('tr');
        const cells = [...values, ...extra.map(([, data]) => data[i])].map(value => cell('td', value));
        if (activePair?.includes(i)) row.classList.add('correlation-active');
        if (animate && selected !== 'kendall') {
          const firstNew = selected === 'pearson' && step === 2 ? 5 : step === 1 ? 3 : cells.length;
          cells.slice(firstNew).forEach(item => item.classList.add('correlation-active', 'correlation-enter'));
        }
        row.append(...cells, ...placeholders('td'));
        return row;
      }));
      byId('correlation-explanation').replaceChildren(...visibleSteps.map(([title, detail, formula], i) => {
        const item = document.createElement('li');
        const explanation = cell('span', detail);
        explanation.className = 'correlation-detail';
        item.append(cell('strong', title), explanation);
        if (formula) {
          item.classList.add('correlation-result');
          if (selected !== 'pearson') item.classList.add('correlation-result-inline');
          const equation = document.createElement('div');
          equation.className = 'correlation-formula';
          equation.innerHTML = formula;
          item.append(equation);
        }
        if (animate && i === step - 1) item.classList.add('correlation-enter');
        return item;
      }));
      back.disabled = step === 0;
      next.disabled = all.disabled = step === steps[selected].length;
    }

    next.addEventListener('click', () => { step++; draw(); });
    back.addEventListener('click', () => { step--; draw(false); });
    all.addEventListener('click', () => { step = steps[method.value].length; draw(false); });
    method.addEventListener('change', () => { step = 0; draw(false); });
    draw(false);
  }

  function setupGrades() {
    const canvas = byId('grades-demo').querySelector('canvas');
    const toggle = byId('show-counts');
    const grades = [[5,4],[2,2],[3,3],[4,1],[6,2],[1,2],[9,8],[10,8],[2,2],[5,4]];
    const counts = new Map();
    grades.forEach(pair => {
      const key = pair.join(',');
      counts.set(key, (counts.get(key) ?? 0) + 1);
    });

    function update() {
      const point = plot(canvas, {
        xlim: [0.45, 10.5], ylim: [0.45, 8.5], xLabel: 'Math grade', yLabel: 'Physics grade',
        xTicks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], yTicks: [1, 2, 3, 4, 5, 6, 7, 8]
      });
      counts.forEach((count, key) => {
        const [x, y] = key.split(',').map(Number);
        const scaled = toggle.checked;
        point(x, y, {radius: scaled ? 11 * Math.sqrt(count) : 7, alpha: 1,
          label: scaled && count > 1 ? String(count) : ''});
      });
      set('grade-caption', toggle.checked
        ? 'The larger dots each represent two students. Both coefficients use all ten observations.'
        : 'Ten students gave these grades. How many distinct dots can you see?');
    }
    const [, spearman, tau] = correlations(grades);
    set('grades-spearman', number(spearman));
    set('grades-kendall', number(tau));
    toggle.addEventListener('change', update);
    update();
  }

  function setupIris() {
    const canvas = byId('iris-demo').querySelector('canvas');
    const toggle = byId('group-iris');
    const metrics = byId('iris-metrics');
    const points = JSON.parse(byId('iris-data').textContent);
    const names = ['Setosa', 'Versicolor', 'Virginica'];
    const pooled = correlations(points)[0];
    const bySpecies = names.map((_, i) => correlations(points.filter(point => point[2] === i))[0]);

    function card(label, coefficient, colour) {
      const div = document.createElement('div');
      const title = document.createElement('span');
      const value = document.createElement('output');
      title.textContent = label;
      value.textContent = number(coefficient);
      div.style.setProperty('--metric-color', colour);
      div.append(title, value);
      metrics.append(div);
    }

    function update() {
      const point = plot(canvas, {
        xlim: [1.8, 4.6], ylim: [.5, 7.2], xLabel: 'Sepal width (cm)', yLabel: 'Petal length (cm)',
        xTicks: [2, 2.5, 3, 3.5, 4, 4.5], yTicks: [1, 2, 3, 4, 5, 6, 7]
      });
      points.forEach(([x, y, species]) => point(x, y, {
        colour: toggle.checked ? palette[species] : ink,
        alpha: .68, radius: 5, diamond: toggle.checked && species === 1
      }));
      metrics.replaceChildren();
      card('All flowers · Pearson’s r', pooled, muted);
      if (toggle.checked) names.forEach((name, i) => card(name, bySpecies[i], palette[i]));
    }
    toggle.addEventListener('change', update);
    update();
  }

  // Let focused form controls handle arrows and space before Reveal receives them.
  document.querySelectorAll('.assoc-demo').forEach(demo => {
    demo.addEventListener('keydown', event => {
      if (/^(INPUT|SELECT|BUTTON)$/.test(event.target.tagName) &&
          ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' ', 'Home', 'End'].includes(event.key)) {
        event.stopPropagation();
      }
    });
  });
  function formatFraction(element) {
    const expression = element.textContent.trim();
    const comparison = expression.includes('÷');
    const parts = expression.split(comparison ? /\s*÷\s*/ : /\s*\/\s*/);
    if (parts.length !== 2 || parts.some(part => !/^\d+(?:\.\d+)?(?:\s*\/\s*\d+)?$/.test(part))) return;

    const lines = parts.map((part, index) => {
      const line = document.createElement('span');
      line.textContent = part;
      if (comparison) line.classList.add(index === 0 ? 'placebo-key' : 'treatment-key');
      return line;
    });
    element.classList.add('assoc-fraction');
    element.setAttribute('aria-label', expression);
    element.replaceChildren(...lines);
  }

  document.querySelectorAll('.static-fraction').forEach(formatFraction);
  setupBinary();
  setupMeans();
  setupPatterns();
  setupCorrelationSteps();
  setupGrades();
  setupIris();
  document.fonts.ready.then(() => {
    byId('mean-shift').dispatchEvent(new Event('input'));
    for (const id of ['scatter-shape', 'show-counts', 'group-iris']) {
      byId(id).dispatchEvent(new Event('change'));
    }
  });
})();

options(repos = c(CRAN = "https://mirror.truenetwork.ru/CRAN/"))

packages <- c("tidyverse", "writexl", "rmarkdown")
available <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
missing_packages <- packages[!available]

if (length(missing_packages) > 0L) {
  install.packages(missing_packages)

  available <- vapply(missing_packages, requireNamespace, logical(1), quietly = TRUE)
  if (any(!available)) {
    stop("Could not install: ", paste(missing_packages[!available], collapse = ", "))
  }
}

message("All packages for Working with Dataframes are ready.")
